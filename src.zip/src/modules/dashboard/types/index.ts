export  interface RoleTitles {
  [key: string]: string;
}