
export type UserDashboardProps = {
  role: string;
  Dates:string
};
export interface AccountManagerViewProps {
  Dates: string; 
}