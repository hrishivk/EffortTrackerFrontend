export interface UserModalProps {
  data?:any
  visible: boolean;
  onClose: () => void;
  onUpdate:()=>void
}