
export interface ProjectModalProps{
  visible:boolean,
  onClose:()=>void
}
export interface project {
  id:number;
  domain:string;
  name:string;
  description:string

}