

const SpinLoader = () => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none">
      <style>
        {`
          @keyframes rotate-ring {
            100% {
              transform: rotate(360deg);
            }
          }

          @keyframes dash-ring {
            0% {
              stroke-dasharray: 1, 150;
              stroke-dashoffset: 0;
            }
            50% {
              stroke-dasharray: 90, 150;
              stroke-dashoffset: -40px;
            }
            100% {
              stroke-dasharray: 90, 150;
              stroke-dashoffset: -120px;
            }
          }

          .spinner-ring {
            animation: rotate-ring 1.4s linear infinite;
            transform-origin: center;
          }

          .spinner-arc {
            animation: dash-ring 1.5s ease-in-out infinite;
          }
        `}
      </style>

      <svg
        className="w-16 h-16 spinner-ring"
        viewBox="25 25 50 50"
      >
        <circle
          className="spinner-arc"
          cx="50"
          cy="50"
          r="20"
          fill="none"
          stroke="rgb(150, 76, 235)"
          strokeWidth="4"
          strokeLinecap="round"
        />
      </svg>
    </div>
  );
};

export default SpinLoader;
