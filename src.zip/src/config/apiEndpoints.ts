
export const API_URL={
    amService: "http://localhost:7001/auth-role-Am",
    spService: "http://localhost:7001/auth-role-Sp",
    apiService:"http://localhost:7001/auth-role",
    userService: "http://localhost:7001/user",
}